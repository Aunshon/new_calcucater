package com.example.aunshon.calculatoraunshon;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button zero;
    private Button one;
    private Button two;
    private Button three;
    private Button four;
    private Button five;
    private Button six;
    private Button seven;
    private Button eight;
    private Button nine;
    private Button add;
    private Button mul;
    private Button div;
    private Button sub;
    private Button point;
    private Button plusminus;
    private Button equal;
    private Button clear;
    private Button delete;
    private TextView result;
    private TextView screen;
    private final char ADDITION='+';
    private final char SUBSTRACTION='-';
    private final char DIVISION='/';
    private final char MULTIPLICATION='*';
    private final char EQU=0;
    private double value1=Double.NaN;
    private double value2;
    private double temp1;
    private double temp2;
    private char ACTION;
    private double ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupUIView();
        zero.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"0");
            }
        });

        one.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"1");
            }
        });

        two.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"2");
            }
        });

        three.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"3");
            }
        });

        four.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"4");
            }
        });

        five.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"5");
            }
        });

        six.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"7");
            }
        });

        eight.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"8");
            }
        });

        point.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+".");
            }
        });

        nine.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(screen.getText()+"9");
            }
        });

        clear.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                screen.setText(null);
                result.setText(null);
                value1=Double.NaN;
                value2=Double.NaN;
            }
        });

        add.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                value1=Double.parseDouble(screen.getText().toString());
                compute();
                ACTION=ADDITION;
                result.setText(toString().valueOf(value1)+" + ");
                screen.setText(null);
            }
        });

        mul.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                value1=Double.parseDouble(screen.getText().toString());
                compute();
                ACTION=MULTIPLICATION;
                result.setText(toString().valueOf(value1)+"x");
                screen.setText(null);
            }
        });

        div.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                value1=Double.parseDouble(screen.getText().toString());
                compute();
                ACTION=DIVISION;
                result.setText(toString().valueOf(value1)+"/");
                screen.setText(null);
            }
        });

        sub.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                value1=Double.parseDouble(screen.getText().toString());
                compute();
                ACTION=SUBSTRACTION;
                result.setText(toString().valueOf(value1)+"-");
                screen.setText(null);
            }
        });



        equal.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                compute();
                ACTION=EQU;
                result.setText(result.getText().toString()+String.valueOf(value2)+"="+String.valueOf(ans));
                screen.setText(String.valueOf(ans));
            }
        });

        plusminus.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                temp1=Double.parseDouble(screen.getText().toString());
                temp2=temp1*(-1);
                screen.setText(toString().valueOf(temp2));
            }
        });

        delete.setOnClickListener(new View.OnClickListener(){
            public void onClick(View V){
                if(screen.getText().length()>0){
                    CharSequence numbers=screen.getText().toString();
                    screen.setText(numbers.subSequence(0,numbers.length()-1));

                }
                else{
                    value1=Double.NaN;
                    value2=Double.NaN;
                    screen.setText(null);
                    result.setText(null);
                }

            }
        });
    }

    private void setupUIView(){
        zero=(Button)findViewById(R.id.btnzero);
        one=(Button)findViewById(R.id.btnone);
        two=(Button)findViewById(R.id.btntwo);
        three=(Button)findViewById(R.id.btnthree);
        four=(Button)findViewById(R.id.btnfour);
        five=(Button)findViewById(R.id.btnfive);
        six=(Button)findViewById(R.id.btnsix);
        seven=(Button)findViewById(R.id.btnseven);
        eight=(Button)findViewById(R.id.btneight);
        nine=(Button)findViewById(R.id.btnnine);
        add=(Button)findViewById(R.id.btnplus);
        mul=(Button)findViewById(R.id.btnmultiply);
        div=(Button)findViewById(R.id.btndivition);
        sub=(Button)findViewById(R.id.btnminus);
        point=(Button)findViewById(R.id.btnpoint);
        plusminus=(Button)findViewById(R.id.btnplusminus);
        equal=(Button)findViewById(R.id.btnequal);
        clear=(Button)findViewById(R.id.btnclear);
        delete=(Button)findViewById(R.id.btndelete);
        screen=(TextView)findViewById(R.id.display);
        result=(TextView)findViewById(R.id.resultfield);


    }
    public void compute(){
        if(!Double.isNaN(value1)){
            value2=Double.parseDouble(screen.getText().toString());

            switch (ACTION){
                case SUBSTRACTION:
                    ans=value1-value2;
                    break;
                case MULTIPLICATION:
                    ans=value1*value2;
                    break;
                case DIVISION:
                    ans=value1/value2;
                    break;
                case ADDITION:
                    ans=value1+value2;
                    break;
                case EQU:

                    break;

            }
        }
        else
            value1=Double.parseDouble(screen.getText().toString());
    }
}
